#include <iostream>
#include <conio.h>
using namespace std;
void ersem(char x[][120], int rHero, int cHero)
{
	for (int r = 0; r < 100; r++)
	{
		for (int c = 0; c < 120; c++)
		{
			x[r][c] = ' ';
		}
	}

	for (int c = 0; c < 120; c++)
	{
		x[0][c] = '^';
		x[90][c] = '_';
	}

	for (int r = 0; r < 90; r++)
	{
		x[r][0] = '|';
		x[r][119] = '|';
	}

	for (int c = 0; c < 119; c++)
	{
		x[75][c] = 'X';
	}
	for (int c = 0; c < 119; c++)
	{
		x[60][c] = 'X';
	}

	for (int c = 40; c < 48; c++)
	{
		x[75][c] = ' ';
	}
}
void disp(char x[][120], int& rHero, int& cHero)
{
	system("cls");
	int r, c;
	for (r = rHero - 20; r < rHero + 5; r++)
	{
		for (c = cHero - 30; c < cHero + 70; c++)
		{
			if (r < 0)
			{
				r = 0;
			}

			if (c < 0)
			{
				c = 0;
			}

			if (c > 119)
			{
				x[r][c] = ' ';
			}

			cout << x[r][c];
		}
		cout << endl;
	}
}
void switchfunc(char x[][120], char movement, int& onoff)
{
	if (movement == 't')
	{
		onoff = 1;
	}
}
void drawswitch1(char x[][120], int& onoff)
{
	if (onoff == -1)
	{
		x[61][57] = 192, x[61][58] = '_', x[61][59] = '_', x[61][60] = 217, x[62][59] = 92, x[63][60] = '*';
	}
	else
	{
		x[61][79] = 192, x[61][80] = '_', x[61][81] = '_', x[61][82] = 217, x[62][81] = 47, x[63][80] = '*';
	}
}
void drawlaser(char x[][120], int onoff)
{
	int r, c;
	if (onoff == -1)
	{
		for (r = 50; r < 60; r++)
		{
			x[r][80] = 219;
		}
	}
	else
	{
		for (r = 50; r < 60; r++)
		{
			x[r][80] = ' ';
		}
	}
}
void drawlift(char x[][120], int rlift, int clift)
{
	int r;
	x[rlift][clift] = 200, x[rlift][clift + 1] = 205, x[rlift][clift + 2] = '=', x[rlift][clift + 3] = '=', x[rlift][clift + 4] = '=', x[rlift][clift + 5] = '=', x[rlift][clift + 6] = '=', x[rlift][clift + 7] = '=', x[rlift][clift + 8] = '=', x[rlift][clift + 9] = 188;
	x[rlift - 1][clift] = 204, x[rlift - 1][clift + 1] = '=', x[rlift - 1][clift + 2] = '=', x[rlift - 1][clift + 3] = '=', x[rlift - 1][clift + 4] = '=', x[rlift - 1][clift + 5] = '=', x[rlift - 1][clift + 6] = '=', x[rlift - 1][clift + 7] = '=', x[rlift - 1][clift + 8] = '=', x[rlift - 1][clift + 9] = 185;
	x[rlift - 2][clift] = 186, x[rlift - 2][clift + 9] = 186;
	x[rlift - 3][clift] = 186, x[rlift - 3][clift + 9] = 186;
	x[rlift - 4][clift] = 186, x[rlift - 4][clift + 9] = 186;
	x[rlift - 5][clift] = 186, x[rlift - 5][clift + 9] = 186;
	x[rlift - 6][clift] = 204, x[rlift - 6][clift + 1] = 205, x[rlift - 6][clift + 2] = 205, x[rlift - 6][clift + 3] = 205, x[rlift - 6][clift + 4] = 205, x[rlift - 6][clift + 5] = 205, x[rlift - 6][clift + 6] = 205, x[rlift - 6][clift + 7] = 205, x[rlift - 6][clift + 8] = 205, x[rlift - 6][clift + 9] = 185;
	x[rlift - 7][clift] = 201, x[rlift - 7][clift + 1] = 205, x[rlift - 7][clift + 2] = 205, x[rlift - 7][clift + 3] = 205, x[rlift - 7][clift + 4] = 202, x[rlift - 7][clift + 5] = 205, x[rlift - 7][clift + 6] = 205, x[rlift - 7][clift + 7] = 205, x[rlift - 7][clift + 8] = 205, x[rlift - 7][clift + 9] = 187;
	x[rlift - 5][clift + 3] = 201, x[rlift - 5][clift + 4] = 205, x[rlift - 5][clift + 5] = 205, x[rlift - 5][clift + 6] = 187;
	x[rlift - 4][clift + 3] = 186, x[rlift - 4][clift + 6] = 186;
	x[rlift - 3][clift + 3] = 200, x[rlift - 3][clift + 4] = 205, x[rlift - 3][clift + 5] = 205, x[rlift - 3][clift + 6] = 188;
	x[rlift - 6][clift + 3] = 'L', x[rlift - 6][clift + 4] = 'I', x[rlift - 6][clift + 5] = 'F', x[rlift - 6][clift + 6] = 'T';
	x[rlift - 2][clift + 8] = 'I';
	for (r = 8; r < 19; r++)
	{
		x[rlift - r][clift + 4] = 186;
	}

}
void movelift(int& rlift, int& dilift)
{




	if (rlift == 74)
	{
		dilift = -1;
	}
	if (rlift == 50)
	{
		dilift = 1;
	}
	if (dilift == 1)
	{
		rlift++;
	}
	if (dilift == -1)
	{
		rlift--;
	}

}
void FALLDOWN(char X[][120], int& rHero, int& cHero, int& dirFAll, int& FD)
{
	if (dirFAll == 1)
	{
		rHero++;
	}

	if (X[rHero + 1][cHero] != ' ')
	{
		dirFAll = -1;
		FD = 0;
	}
	if (X[rHero + 1][cHero] == '=')
	{
		
			rHero-=11;
			FD = 0;
		
		
	}

	
}
void drawbullet(char x[][120], int cbullet)
{
	x[14][cbullet] = 'o';
}
void movebullet(int& cbullet, int& dibullet)
{
	if (cbullet == 116)
	{
		dibullet = -1;
	}
	if (cbullet == 2)
	{
		cbullet = 117;
	}
	if (dibullet == -1)
	{
		cbullet--;
	}
}
void ErsemLadder(char X[][120], int rLadder, int cLadder)
{
	X[rLadder][cLadder] = 'H';
	X[rLadder][cLadder + 1] = 205;
	X[rLadder - 1][cLadder] = 'H';
	X[rLadder - 1][cLadder + 1] = 205;
	X[rLadder - 2][cLadder] = 'H';
	X[rLadder - 2][cLadder + 1] = 205;
	X[rLadder - 3][cLadder] = 'H';
	X[rLadder - 3][cLadder + 1] = 205;
	X[rLadder - 4][cLadder] = 'H';
	X[rLadder - 4][cLadder + 1] = 205;
	X[rLadder - 5][cLadder] = 'H';
	X[rLadder - 5][cLadder + 1] = 205;
	X[rLadder - 6][cLadder] = 'H';
	X[rLadder - 6][cLadder + 1] = 205;
	X[rLadder - 7][cLadder] = 'H';
	X[rLadder - 7][cLadder + 1] = 205;
	X[rLadder][cLadder + 2] = 205;
	X[rLadder][cLadder + 3] = 185;
	X[rLadder - 1][cLadder + 2] = 205;
	X[rLadder - 1][cLadder + 3] = 185;
	X[rLadder - 2][cLadder + 2] = 205;
	X[rLadder - 2][cLadder + 3] = 185;
	X[rLadder - 3][cLadder + 2] = 205;
	X[rLadder - 3][cLadder + 3] = 185;
	X[rLadder - 4][cLadder + 2] = 205;
	X[rLadder - 4][cLadder + 3] = 185;
	X[rLadder - 5][cLadder + 2] = 205;
	X[rLadder - 5][cLadder + 3] = 185;
	X[rLadder - 6][cLadder + 2] = 205;
	X[rLadder - 6][cLadder + 3] = 185;
	X[rLadder - 7][cLadder + 2] = 205;
	X[rLadder - 7][cLadder + 3] = 185;

	X[rLadder - 7][cLadder] = 'H';
	X[rLadder - 7][cLadder + 1] = 205;
	X[rLadder - 8][cLadder] = 'H';
	X[rLadder - 8][cLadder + 1] = 205;
	X[rLadder - 9][cLadder] = 'H';
	X[rLadder - 9][cLadder + 1] = 205;
	X[rLadder - 10][cLadder] = 'H';
	X[rLadder - 10][cLadder + 1] = 205;
	X[rLadder - 11][cLadder] = 'H';
	X[rLadder - 11][cLadder + 1] = 205;
	X[rLadder - 12][cLadder] = 'H';
	X[rLadder - 12][cLadder + 1] = 205;
	X[rLadder - 13][cLadder] = 'H';
	X[rLadder - 13][cLadder + 1] = 205;

	X[rLadder - 8][cLadder + 2] = 205;
	X[rLadder - 8][cLadder + 3] = 185;
	X[rLadder - 9][cLadder + 2] = 205;
	X[rLadder - 9][cLadder + 3] = 185;
	X[rLadder - 10][cLadder + 2] = 205;
	X[rLadder - 10][cLadder + 3] = 185;
	X[rLadder - 11][cLadder + 2] = 205;
	X[rLadder - 11][cLadder + 3] = 185;
	X[rLadder - 12][cLadder + 2] = 205;
	X[rLadder - 12][cLadder + 3] = 185;
	X[rLadder - 13][cLadder + 2] = 205;
	X[rLadder - 13][cLadder + 3] = 185;
}
void DrawEnmy1(char x[][120], int RE1, int CE1, int& flagde1)
{
	x[RE1][CE1 - 1] = '(';
	x[RE1][CE1 + 1] = '_';
	x[RE1][CE1 + 2] = '_';
	x[RE1][CE1 + 3] = '_';
	x[RE1][CE1 + 5] = ')';
	x[RE1 - 1][CE1 + 5] = 16;
	x[RE1 - 1][CE1 - 1] = '<';
	x[RE1 - 1][CE1 + 1] = '|';
	x[RE1 - 1][CE1 + 2] = '-';
	x[RE1 - 1][CE1 + 3] = '|';
	x[RE1 - 2][CE1 + 3] = 30;
	x[RE1 - 2][CE1 + 2] = 30;
	x[RE1 - 2][CE1 + 1] = 30;
	if (flagde1 == 1)
	{

		x[RE1][CE1 - 1] = ' ';
		x[RE1][CE1 + 1] = ' ';
		x[RE1][CE1 + 2] = ' ';
		x[RE1][CE1 + 3] = ' ';
		x[RE1][CE1 + 5] = ' ';
		x[RE1 - 1][CE1 + 5] = ' ';
		x[RE1 - 1][CE1 - 1] = ' ';
		x[RE1 - 1][CE1 + 1] = ' ';
		x[RE1 - 1][CE1 + 2] = ' ';
		x[RE1 - 1][CE1 + 3] = ' ';
		x[RE1 - 2][CE1 + 3] = ' ';
		x[RE1 - 2][CE1 + 2] = ' ';
		x[RE1 - 2][CE1 + 1] = ' ';

	}

}
void MoveEnmy1(int& CE1, int& dirE1)
{
	if (dirE1 == 1)
	{
		if (CE1 < 85)
		{
			CE1++;
		}
		else
		{
			dirE1 = -1;
		}
	}
	else
	{
		if (CE1 > 104)
		{
			CE1--;
		}
		else
		{
			dirE1 = 1;
		}
	}
}
void DrawEnmy2(char x[][120], int RE2, int CE2, int& flagde2)
{

	x[RE2][CE2] = 192;
	x[RE2][CE2 + 1] = '-';
	x[RE2][CE2 + 2] = '-';
	x[RE2][CE2 + 3] = '-';
	x[RE2][CE2 + 4] = '-';
	x[RE2][CE2 + 5] = '-';
	x[RE2][CE2 + 6] = '-';
	x[RE2][CE2 + 7] = '-';
	x[RE2][CE2 + 8] = '-';
	x[RE2][CE2 + 9] = '-';
	x[RE2][CE2 + 10] = '-';
	x[RE2][CE2 + 11] = 217;
	x[RE2 - 1][CE2 + 11] = '|';
	x[RE2 - 1][CE2] = '|';
	x[RE2 - 1][CE2 + 1] = '(';
	x[RE2 - 1][CE2 + 2] = '0';
	x[RE2 - 1][CE2 + 3] = ')';
	x[RE2 - 1][CE2 + 4] = '(';
	x[RE2 - 1][CE2 + 5] = '0';
	x[RE2 - 1][CE2 + 6] = ')';
	x[RE2 - 1][CE2 + 7] = '(';
	x[RE2 - 1][CE2 + 8] = '0';
	x[RE2 - 1][CE2 + 9] = ')';
	x[RE2 - 1][CE2 + 10] = '*';

	x[RE2 - 2][CE2 + 11] = '>';
	x[RE2 - 2][CE2 + 1] = '-';
	x[RE2 - 2][CE2 + 2] = '-';
	x[RE2 - 2][CE2 + 3] = '-';
	x[RE2 - 2][CE2 + 4] = '-';
	x[RE2 - 2][CE2 + 5] = '-';
	x[RE2 - 2][CE2 + 6] = '-';
	x[RE2 - 2][CE2 + 7] = '-';
	x[RE2 - 2][CE2 + 8] = '-';
	x[RE2 - 2][CE2 + 9] = '-';
	x[RE2 - 2][CE2 + 10] = '-';
	x[RE2 - 2][CE2] = 218;
	x[RE2 - 3][CE2 + 12] = '/';
	x[RE2 - 4][CE2 + 13] = '/';
	x[RE2 - 5][CE2 + 13] = 92;
	x[RE2 - 6][CE2 + 1] = '_';
	x[RE2 - 6][CE2 + 2] = '_';
	x[RE2 - 6][CE2 + 3] = '_';
	x[RE2 - 6][CE2 + 4] = '_';
	x[RE2 - 6][CE2 + 5] = '_';
	x[RE2 - 6][CE2 + 6] = '_';
	x[RE2 - 6][CE2 + 7] = '_';
	x[RE2 - 6][CE2 + 8] = '_';
	x[RE2 - 6][CE2] = '_';
	x[RE2 - 6][CE2 + 9] = '_';
	x[RE2 - 6][CE2 + 10] = '_';
	x[RE2 - 5][CE2 - 1] = '_';
	x[RE2 - 3][CE2 - 1] = 92;
	x[RE2 - 4][CE2 - 2] = 92;
	x[RE2 - 5][CE2 - 2] = 47;
	x[RE2 - 7][CE2 + 5] = '|';
	x[RE2 - 7][CE2 + 2] = '|';
	x[RE2 - 8][CE2 + 2] = 218;
	x[RE2 - 8][CE2 + 5] = 191;
	x[RE2 - 8][CE2 + 3] = '-';
	x[RE2 - 8][CE2 + 4] = '-';
	x[RE2 - 7][CE2 + 6] = '-';
	x[RE2 - 7][CE2 + 7] = '-';
	x[RE2 - 7][CE2 + 8] = '-';
	x[RE2 - 7][CE2 + 9] = '|';
	x[RE2 - 8][CE2 + 6] = '-';
	x[RE2 - 8][CE2 + 7] = '-';
	x[RE2 - 8][CE2 + 8] = '-';
	x[RE2 - 8][CE2 + 9] = '|';
	if (flagde2 == 1)
	{
		x[RE2][CE2] = ' ';
		x[RE2][CE2 + 1] = ' ';
		x[RE2][CE2 + 2] = ' ';
		x[RE2][CE2 + 3] = ' ';
		x[RE2][CE2 + 4] = ' ';
		x[RE2][CE2 + 5] = ' ';
		x[RE2][CE2 + 6] = ' ';
		x[RE2][CE2 + 7] = ' ';
		x[RE2][CE2 + 8] = ' ';
		x[RE2][CE2 + 9] = ' ';
		x[RE2][CE2 + 10] = ' ';
		x[RE2][CE2 + 11] = ' ';
		x[RE2 - 1][CE2 + 11] = ' ';
		x[RE2 - 1][CE2] = ' ';
		x[RE2 - 1][CE2 + 1] = ' ';
		x[RE2 - 1][CE2 + 2] = ' ';
		x[RE2 - 1][CE2 + 3] = ' ';
		x[RE2 - 1][CE2 + 4] = ' ';
		x[RE2 - 1][CE2 + 5] = ' ';
		x[RE2 - 1][CE2 + 6] = ' ';
		x[RE2 - 1][CE2 + 7] = ' ';
		x[RE2 - 1][CE2 + 8] = ' ';
		x[RE2 - 1][CE2 + 9] = ' ';
		x[RE2 - 1][CE2 + 10] = ' ';

		x[RE2 - 2][CE2 + 11] = ' ';
		x[RE2 - 2][CE2 + 1] = ' ';
		x[RE2 - 2][CE2 + 2] = ' ';
		x[RE2 - 2][CE2 + 3] = ' ';
		x[RE2 - 2][CE2 + 4] = ' ';
		x[RE2 - 2][CE2 + 5] = ' ';
		x[RE2 - 2][CE2 + 6] = ' ';
		x[RE2 - 2][CE2 + 7] = ' ';
		x[RE2 - 2][CE2 + 8] = ' ';
		x[RE2 - 2][CE2 + 9] = ' ';
		x[RE2 - 2][CE2 + 10] = ' ';
		x[RE2 - 2][CE2] = ' ';
		x[RE2 - 3][CE2 + 12] = ' ';
		x[RE2 - 4][CE2 + 13] = ' ';
		x[RE2 - 5][CE2 + 13] = ' ';
		x[RE2 - 6][CE2 + 1] = ' ';
		x[RE2 - 6][CE2 + 2] = ' ';
		x[RE2 - 6][CE2 + 3] = ' ';
		x[RE2 - 6][CE2 + 4] = ' ';
		x[RE2 - 6][CE2 + 5] = ' ';
		x[RE2 - 6][CE2 + 6] = ' ';
		x[RE2 - 6][CE2 + 7] = ' ';
		x[RE2 - 6][CE2 + 8] = ' ';
		x[RE2 - 6][CE2] = ' ';
		x[RE2 - 6][CE2 + 9] = ' ';
		x[RE2 - 6][CE2 + 10] = ' ';
		x[RE2 - 5][CE2 - 1] = ' ';
		x[RE2 - 3][CE2 - 1] = ' ';
		x[RE2 - 4][CE2 - 2] = ' ';
		x[RE2 - 5][CE2 - 2] = ' ';
		x[RE2 - 7][CE2 + 5] = ' ';
		x[RE2 - 7][CE2 + 2] = ' ';
		x[RE2 - 8][CE2 + 2] = ' ';
		x[RE2 - 8][CE2 + 5] = ' ';
		x[RE2 - 8][CE2 + 3] = ' ';
		x[RE2 - 8][CE2 + 4] = ' ';
		x[RE2 - 7][CE2 + 6] = ' ';
		x[RE2 - 7][CE2 + 7] = ' ';
		x[RE2 - 7][CE2 + 8] = ' ';
		x[RE2 - 7][CE2 + 9] = ' ';
		x[RE2 - 8][CE2 + 6] = ' ';
		x[RE2 - 8][CE2 + 7] = ' ';
		x[RE2 - 8][CE2 + 8] = ' ';
		x[RE2 - 8][CE2 + 9] = ' ';
	}
}
void DrawEnmy3(char x[][120], int RE3, int CE3, int chbull, int& flagbulle)
{
	x[RE3][CE3 - 2] = '(';
	x[RE3 + 1][CE3 - 2] = '|';
	x[RE3 + 2][CE3 - 2] = '|';
	x[RE3 + 3][CE3 - 2] = '|';
	x[RE3 + 4][CE3 - 2] = '|';
	x[RE3 + 1][CE3 - 3] = '@';
	x[RE3 + 2][CE3 - 3] = '@';
	x[RE3 + 3][CE3 - 3] = '@';
	x[RE3 + 4][CE3 - 3] = '@';
	x[RE3][CE3 - 3] = '/';
	x[RE3 + 1][CE3 - 5] = '~';
	x[RE3 + 2][CE3 - 6] = '~';
	x[RE3 + 3][CE3 - 6] = '|';
	x[RE3 + 4][CE3 - 6] = '|';
	x[RE3 + 2][CE3 - 7] = '@';
	x[RE3 + 3][CE3 - 7] = '@';
	x[RE3 + 4][CE3 - 7] = '@';
	x[RE3 + 1][CE3 + 1] = '^';
	x[RE3 + 2][CE3 + 2] = '^';
	x[RE3 + 3][CE3 + 3] = '|';
	x[RE3 + 4][CE3 + 3] = '|';
	x[RE3 + 1][CE3 + 5] = '$';
	x[RE3 + 2][CE3 + 5] = '|';
	x[RE3 + 3][CE3 + 5] = '|';
	x[RE3 + 4][CE3 + 5] = '|';
	x[RE3 + 2][CE3 + 6] = '*';
	x[RE3 + 3][CE3 + 6] = '*';
	x[RE3 + 4][CE3 + 6] = '*';
	x[RE3 + 1][CE3 + 8] = '^';
	x[RE3 + 2][CE3 + 8] = '|';
	x[RE3 + 3][CE3 + 8] = '|';
	x[RE3 + 4][CE3 + 8] = '|';
	x[RE3 + 2][CE3 + 9] = '*';
	x[RE3 + 3][CE3 + 9] = '*';
	x[RE3 + 4][CE3 + 9] = '*';
	x[RE3][CE3 + 6] = ')';
	x[RE3 - 1][CE3 + 5] = '*';
	x[RE3 - 1][CE3 - 1] = '@';
	x[RE3 - 2][CE3 + 5] = '*';
	x[RE3 - 2][CE3 - 1] = '*';
	x[RE3 - 2][CE3 + 1] = '|';
	x[RE3 - 1][CE3 + 2] = '-';
	x[RE3 - 2][CE3 + 3] = '|';
	x[RE3 - 3][CE3 + 3] = '#';
	x[RE3 - 3][CE3 + 2] = '#';
	x[RE3 - 3][CE3 + 1] = '#';

	if (flagbulle == 1)
	{
		int r = RE3 - 1;
		chbull = CE3 + 8;
		for (int i = 0; ; i++)
		{
			x[r][chbull] = 175;
			x[r][chbull - 1] = ' ';
			x[r][CE3 + 1] = 111;
			chbull++;
			if (x[r][chbull] != ' ')
			{
				flagbulle = 0;
				//	if (x[r][chbullet] == '<')
				//	{

					//	flagde1 = 1;

					//}
				break;
			}

		}
	}

}
void MoveEnmy3(int& RE3, int& CE3, int& dirE3)
{
	if (dirE3 == 1)
	{
		if (CE3 < 110)
		{
			CE3++;
		}
		else
		{
			dirE3 = -1;
		}
	}
	else
	{

		if (CE3 > 90)
		{
			CE3--;
		}
		else
		{
			dirE3 = 1;
		}

	}
}
void Drawbullett(char x[][120], int cbullet3, int RE3)
{


	x[RE3 + 2][cbullet3] = '<';
	x[RE3 + 3][cbullet3] = '<';
	x[RE3 + 4][cbullet3] = '<';
}
void Movebullett(int& cbullet3, int& dibullett, int& diehero)
{
	if (cbullet3 == 70)
	{
		dibullett = -1;
	}
	if (cbullet3 == 60)
	{
		cbullet3 = 69;
	}
	if (dibullett == -1)
	{
		cbullet3--;
	}
	if (cbullet3=='|')
	{
		diehero = 1;
	}
	if (cbullet3 == 'O')
	{
		diehero = 1;
	}
}
void MoveEnmy2(int& RE2, int& CE2, int& dirE2)
{
	if (dirE2 == 1)
	{
		if (CE2 < 40)
		{
			CE2++;
		}
		else
		{
			dirE2 = -1;
		}
	}
	else
	{

		if (CE2 > 20)
		{
			CE2--;
		}
		else
		{
			dirE2 = 1;
		}

	}
}
void Drawbullet(char x[][120], int cEbullet, int RE2)
{
	x[RE2 - 8][cEbullet] = '>';

	x[RE2 - 7][cEbullet] = '>';
}
void Movebullet(int& cEbullet, int& dibullet)
{
	if (cEbullet == 118)
	{
		dibullet = -1;
	}
	if (cEbullet == 24)
	{
		cEbullet = 117;
	}
	if (dibullet == -1)
	{
		cEbullet--;
	}
}
void ersmhero(char x[][120], int rhero, int chero, int& FD, int& dirFall, int& flagup,int& diehero)
{
	if (diehero == 1) {


		x[rhero][chero + 1] = 93;
		x[rhero][chero + 2] = 91;
		x[rhero][chero + 3] = 93;
		x[rhero][chero + 4] = 91;
		x[rhero][chero + 5] = 93;
		x[rhero][chero] = 47;
		x[rhero][chero - 1] = 92;
		x[rhero][chero + 6] = 92;
		x[rhero][chero + 7] = '|';
		x[rhero - 1][chero - 1] = 124;
		x[rhero - 1][chero + 1] = 47;
		x[rhero - 1][chero + 6] = 92;
		x[rhero - 1][chero + 6] = 124;
		x[rhero - 1][chero + 7] = '|';
		x[rhero - 2][chero - 1] = 124;
		x[rhero - 2][chero] = 124;
		x[rhero - 2][chero + 1] = 47;
		x[rhero - 2][chero + 2] = 40;
		x[rhero - 2][chero + 3] = '=';
		x[rhero - 2][chero + 4] = '=';
		x[rhero - 2][chero + 5] = '=';
		x[rhero - 2][chero + 6] = '=';
		x[rhero - 2][chero + 7] = '|';
		x[rhero - 3][chero - 1] = 47;
		x[rhero - 3][chero + 7] = 'O';
		x[rhero - 4][chero] = 40;
		x[rhero - 4][chero + 1] = '_';
		x[rhero - 4][chero + 2] = '_';
		x[rhero - 4][chero + 3] = 47;
		x[rhero - 4][chero + 4] = 92;
		x[rhero - 4][chero + 5] = '_';
		x[rhero - 4][chero + 6] = '_';
		x[rhero - 4][chero + 7] = 41;
		x[rhero - 5][chero] = 124;
		x[rhero - 5][chero + 2] = 60;
		x[rhero - 5][chero + 3] = 62;
		x[rhero - 5][chero + 5] = 60;
		x[rhero - 5][chero + 6] = 62;
		x[rhero - 5][chero + 7] = 124;
		x[rhero - 6][chero + 1] = 47;
		x[rhero - 6][chero + 2] = 205;
		x[rhero - 6][chero + 3] = 205;
		x[rhero - 6][chero + 4] = 205;
		x[rhero - 6][chero + 5] = 205;
		x[rhero - 6][chero + 6] = 92;
		x[rhero - 7][chero + 2] = '_';
		x[rhero - 7][chero + 3] = '_';
		x[rhero - 7][chero + 4] = '_';
		x[rhero - 7][chero + 5] = '_';
	}
	
	if (x[rhero-3][chero+8]=='<')
	{
		x[rhero][chero + 1] = ' ';
		x[rhero][chero + 2] = ' ';
		x[rhero][chero + 3] = ' ';
		x[rhero][chero + 4] = ' ';
		x[rhero][chero + 5] = ' ';
		x[rhero][chero] = ' ';
		x[rhero][chero - 1] = ' ';
		x[rhero][chero + 6] = ' ';
		x[rhero][chero + 7] = ' ';
		x[rhero - 1][chero - 1] = ' ';;
		x[rhero - 1][chero + 1] = ' ';
		x[rhero - 1][chero + 6] = ' ';
		x[rhero - 1][chero + 6] = ' ';;
		x[rhero - 1][chero + 7] = ' ';;
		x[rhero - 2][chero - 1] = ' ';;
		x[rhero - 2][chero] = ' ';
		x[rhero - 2][chero + 1] = ' ';
		x[rhero - 2][chero + 2] = ' ';
		x[rhero - 2][chero + 3] = ' ';;
		x[rhero - 2][chero + 4] = ' ';;
		x[rhero - 2][chero + 5] = ' ';;
		x[rhero - 2][chero + 6] = ' ';;
		x[rhero - 2][chero + 7] = ' ';;
		x[rhero - 3][chero - 1] = ' ';
		x[rhero - 3][chero + 7] = ' ';
		x[rhero - 4][chero] = ' ';
		x[rhero - 4][chero + 1] = ' ';;
		x[rhero - 4][chero + 2] = ' ';;
		x[rhero - 4][chero + 3] = ' ';
		x[rhero - 4][chero + 4] = ' ';
		x[rhero - 4][chero + 5] = ' ';;
		x[rhero - 4][chero + 6] = ' ';;
		x[rhero - 4][chero + 7] = ' ';
		x[rhero - 5][chero] = ' ';
		x[rhero - 5][chero + 2] = ' ';
		x[rhero - 5][chero + 3] = ' ';
		x[rhero - 5][chero + 5] = ' ';
		x[rhero - 5][chero + 6] = ' ';
		x[rhero - 5][chero + 7] = ' ';;
		x[rhero - 6][chero + 1] = ' ';
		x[rhero - 6][chero + 2] = ' ';;
		x[rhero - 6][chero + 3] = ' ';;
		x[rhero - 6][chero + 4] = ' ';;
		x[rhero - 6][chero + 5] = ' ';;
		x[rhero - 6][chero + 6] = ' ';
		x[rhero - 7][chero + 2] = ' ';;
		x[rhero - 7][chero + 3] = ' ';;
		x[rhero - 7][chero + 4] = ' ';;
		x[rhero - 7][chero + 5] = ' ';;
		diehero = 0;
	}

	if (x[rhero + 1][chero - 2] == ' ' && x[rhero][chero - 3] == ' ')
	{
		FD = 1;
		dirFall = 1;
	}
	if (flagup == 1)
	{
		rhero = 59;
		chero = 3;
	}

}
void Jump(char x[][120], int& a, int& b, int& count, int& flagjump)
{
	if (flagjump == 1)
	{

		count++;
		if (count == 1)
		{
			a -= 2;
			b += 2;
		}
		if (count == 2)
		{
			a -= 2;
			b += 2;
		}
		if (count == 3)
		{
			a -= 2;
			b += 2;
		}
		if (count == 4)
		{
			a += 2;
			b += 2;
		}
		if (count >= 5)
		{
			a += 1;
			b += 2;
		}
		if (count == 6)
		{
			count = 0;
			flagjump = 0;
		}
	}
}
void Jumpshmal(char x[][120], int& a, int& b, int& count, int& flagjump)
{
	if (flagjump == 2)
	{

		count++;
		if (count == 1)
		{
			a -= 3;
			b -= 3;
		}
		if (count == 2)
		{
			a -= 3;
			b -= 3;
		}
		if (count == 3)
		{
			a -= 3;
			b -= 3;
		}
		if (count == 4)
		{
			a += 1;
			b -= 3;
		}
		if (count >= 5)
		{
			//	a += 2;
			b -= 3;
		}
		if (count == 6)
		{
			count = 0;
			flagjump = 0;
		}
	}
}
void harakhero(char x[][120], int& rHero, int& cHero, char movement, int& flagemen, int& flagshmal, int& onoff, int& flagjump, int& flagbull, int& flagbullshmal, int flagup)
{
	if (movement == 'j')
	{
		flagjump = 1;
	}
	if (movement == 'u')
	{
		flagup = 1;
	}
	if (movement == 'b')
	{
		flagbull = 1;
	}
	if (movement == 'v')
	{
		flagbullshmal = 1;
	}
	if (movement == 'h')
	{
		flagjump = 2;
	}

	if (movement == 'w')
	{
		if (x[rHero][cHero - 2] == 'H' || x[rHero + 1][cHero - 2] == 'H')
		{
			rHero--;
		}

	}
	if (movement == 't')
	{
		onoff = 1;

	}
	if (movement == 's')
	{
		if (x[rHero + 1][cHero - 2] == 'H' || x[rHero + 2][cHero - 2] == 'H')
		{
			rHero++;
		}
	}
	if (rHero == 26 && cHero + 6 == 392)
	{
		flagemen = 1;
	}
	else
	{
		flagemen = 0;
	}
	if (flagemen == 0)
	{
		if (movement == 'd')
		{
			if (cHero + 8 < 119)
			{
				cHero++;
			}
		}
	}
	if (rHero == 56 && cHero == 385)
	{
		flagshmal = 1;
	}
	else
	{
		flagshmal = 0;
	}
	if (flagshmal == 0)
	{
		if (movement == 'a')
		{
			if (cHero - 1 != 1)
			{
				cHero--;
			}
		}
	}




}
void bull(char x[][120], int rhero, int chero, char movement, int& flagbull, int& chbullet, int& flagde1)
{
	int r = rhero - 1;
	chbullet = chero + 8;
	for (int i = 0; ; i++)
	{
		x[r][chbullet] = 175;
		x[r][chbullet - 1] = ' ';
		x[r][chero + 1] = 111;
		chbullet++;
		if (x[r][chbullet] != ' ')
		{
			flagbull = 0;
			if (x[r][chbullet] == '<')
			{

				flagde1 = 1;

			}
			break;
		}

	}
}
void bullshmal(char x[][120], int rhero, int chero, char movement, int& flagbullshmal, int& chbullet2, int& flagde2)
{
	int r = rhero - 2;
	chbullet2 = chero - 14;
	for (;;)
	{
		x[r][chbullet2 - 1] = 174;
		//x[r][chbullet2 ] = ' ';
		//x[r][chero - 3] = 111;
		chbullet2--;
		if (x[r][chbullet2] != ' ')
		{
			flagbullshmal = 0;
			if (x[r][chbullet2] == '>')
			{
				flagde2 = 1;
			}
			flagde2 = 1;
			break;
		}


	}
}
void up(char x[][120], int rhero, int chero, int flagup)
{
	if (flagup == 1)
	{
		rhero = 59;
		chero = 3;
	}
}
void main()
{
	int rlift = 74, clift = 1, dilift = 1, onoff = -1, cbullet = 116, dibullet = -1;
	int RE1 = 89, CE1 = 30, dirE1 = 1, flagE1 = 0, RE2 = 74, CE2 = 15, dirE2 = 1;
	int  cEbullet = 24, dirbullet = -1, RE3 = 55, CE3 = 85, dirE3 = 1, dirbullett = -1;
	int cbullet3 = 56;
	int rhero = 89, chero = 10, chbullet = 2;
	int rLadder = 89, cLadder = 70;
	char movement = rhero;
	int count = 0;
	int flagemen = 0;
	int flagshmal = 0;
	int flagjump = 0;
	int FD = 0, dirFall = 1;
	int flagbull = 0;
	int flagbullshmal = 0;
	int flagde1 = 0;
	int flagde2 = 0;
	int chbullet2 = 1;
	int flagup = 0;
	int chbull = 0;
	int flagbulle = 1;
	int diehero = 1;
	char x[100][120];
	for (;;)
	{
		for (; !_kbhit();)
		{
			ersem(x, rhero, chero);
			movebullet(cbullet, dibullet);
			switchfunc(x, movement, onoff);
			drawswitch1(x, onoff);
			drawlaser(x, onoff);
			drawlift(x, rlift, clift);
			movelift(rlift, dilift);
			drawbullet(x, cbullet);
			MoveEnmy1(CE1, dirE1);
			MoveEnmy2(RE2, CE2, dirE2);
			MoveEnmy3(RE3, CE3, dirE3);
			DrawEnmy1(x, RE1, CE1, flagde1);
			Movebullet(cEbullet, dirbullet);
			Drawbullet(x, cEbullet, RE2);
			Movebullett(cbullet3, dirbullett,diehero);
			Drawbullett(x, cbullet3, RE3);
			ErsemLadder(x, rLadder, cLadder);
			ersmhero(x, rhero, chero, FD, dirFall, flagup,diehero);
			if (flagup == 1)
			{
				up(x, rhero, chero, flagup);
			}
			if (FD == 1 && flagjump != 1 && flagshmal != 1)
			{
				FALLDOWN(x, rhero, chero, dirFall, FD);
			}
			if (flagjump == 1)
			{
				Jump(x, rhero, chero, count, flagjump);
			}
			if (flagjump == 2)
			{
				Jumpshmal(x, rhero, chero, count, flagjump);
			}
			if (flagbull == 1)
			{
				bull(x, rhero, chero, movement, flagbull, chbullet, flagde1);
			}
			if (flagbullshmal == 1)
			{
				bullshmal(x, rhero, chero, movement, flagbullshmal, chbullet2, flagde2);
			}
			DrawEnmy2(x, RE2, CE2, flagde2);
			DrawEnmy3(x, RE3, CE3, chbull, flagbulle);
			disp(x, rhero, chero);
		}
		char movement = _getch();
		harakhero(x, rhero, chero, movement, flagemen, flagshmal, onoff, flagjump, flagbull, flagbullshmal, flagup);

	}
}
